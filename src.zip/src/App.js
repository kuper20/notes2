import React from 'react';
import './App.css';
import Manager from './componenets/CCManager'
function App() {
  return (
    <div>
    <Manager/>
    </div>
  )
}
export default App
