import React, { Component } from 'react'
import { withRouter, Link, Button } from 'react-router-dom'
class Notes extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        let mystyle = {
            border: '3px solid orange', // it is not work.
            padding: "10px",
            fontFamily: "Arial"
        }
        return (
            <div style={{ marginLeft: 550, marginRight: 550, textAlign: 'center' }}>
                <h1 style={{ marginLeft: 1 }}>Your notes</h1>
                {this.props.showNotes.map((r, index) =>
                    <p key={index} style={mystyle}>
                        title: {r.titel} <br></br>
                        description: {r.description} <br></br>
                        <button onClick={() => this.props.remove(index)}>delete</button>
                        <Container >
                            <Form>

                                <div>
                                    <Button variant="primary" type="submit" >
                                        <Link to="/Notes" style={{ color: 'red' }}>Notes</Link>
                                    </Button>
                                </div>
                            </Form>
                        </Container>
                    </p>
                )}
            </div>
        )
    }
}
export default withRouter(Notes)